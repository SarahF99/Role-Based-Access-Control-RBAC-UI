<template>
  <div class="p-4">
    <h1 class="text-2xl font-bold mb-6">Role-Based Access Control (RBAC) UI</h1>

    <!-- User Management -->
    <div class="mb-8">
      <h2 class="text-xl font-bold mb-4">User Management</h2>
      <div class="flex gap-2 mb-4">
        <input
          v-model="newUser.name"
          type="text"
          placeholder="User Name"
          class="border p-2 rounded"
        />
        <input
          v-model="newUser.role"
          type="text"
          placeholder="Role"
          class="border p-2 rounded"
        />
        <button @click="addUser" class="bg-blue-500 text-white px-4 py-2 rounded">
          Add User
        </button>
      </div>
      <table class="table-auto w-full border-collapse border border-gray-300">
        <thead>
          <tr>
            <th class="border px-4 py-2">Name</th>
            <th class="border px-4 py-2">Role</th>
            <th class="border px-4 py-2">Status</th>
            <th class="border px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in users" :key="user.id">
            <td class="border px-4 py-2">{{ user.name }}</td>
            <td class="border px-4 py-2">{{ user.role }}</td>
            <td class="border px-4 py-2">{{ user.status }}</td>
            <td class="border px-4 py-2">
              <button
                @click="deleteUser(user.id)"
                class="bg-red-500 text-white px-4 py-2 rounded"
              >
                Delete
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Role Management -->
    <div class="mb-8">
      <h2 class="text-xl font-bold mb-4">Role Management</h2>
      <div class="flex gap-2 mb-4">
        <input
          v-model="newRole"
          type="text"
          placeholder="Role Name"
          class="border p-2 rounded"
        />
        <button @click="addRole" class="bg-green-500 text-white px-4 py-2 rounded">
          Add Role
        </button>
      </div>
      <ul class="list-disc ml-5">
        <li v-for="role in roles" :key="role.id" class="mb-2">
          {{ role.name }}
          <button
            @click="deleteRole(role.id)"
            class="text-red-500 hover:underline ml-2"
          >
            Delete
          </button>
        </li>
      </ul>
    </div>

    <!-- Permissions (Placeholder) -->
    <div>
      <h2 class="text-xl font-bold mb-4">Permission Management</h2>
      <p>Feature under construction!</p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      users: [
        { id: 1, name: "Alice", role: "Admin", status: "Active" },
        { id: 2, name: "Bob", role: "Editor", status: "Inactive" },
      ],
      roles: [
        { id: 1, name: "Admin" },
        { id: 2, name: "Editor" },
      ],
      newUser: { name: "", role: "", status: "Active" },
      newRole: "",
    };
  },
  methods: {
    addUser() {
      if (this.newUser.name && this.newUser.role) {
        this.users.push({ ...this.newUser, id: Date.now() });
        this.newUser = { name: "", role: "", status: "Active" };
      } else {
        alert("Please fill in all fields.");
      }
    },
    deleteUser(userId) {
      this.users = this.users.filter((user) => user.id !== userId);
    },
    addRole() {
      if (this.newRole) {
        this.roles.push({ id: Date.now(), name: this.newRole });
        this.newRole = "";
      } else {
        alert("Role name cannot be empty.");
      }
    },
    deleteRole(roleId) {
      this.roles = this.roles.filter((role) => role.id !== roleId);
    },
  },
};
</script>

<style>
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
</style>

